package nc.vo.vehicle.inspection;

import nc.md.model.IEnumValue;
import nc.md.model.impl.MDEnum;


public class Enumerate0 extends MDEnum{
	public Enumerate0(IEnumValue enumValue){
		super(enumValue);
	}

    public static final Enumerate0 Enumerate0_�����  = MDEnum.valueOf(Enumerate0.class, java.lang.String.valueOf("1"));
    public static final Enumerate0 Enumerate0_������  = MDEnum.valueOf(Enumerate0.class, java.lang.String.valueOf("2"));
    public static final Enumerate0 Enumerate0_�����������  = MDEnum.valueOf(Enumerate0.class, java.lang.String.valueOf("3"));
    public static final Enumerate0 Enumerate0_׼������  = MDEnum.valueOf(Enumerate0.class, java.lang.String.valueOf("4"));
    public static final Enumerate0 Enumerate0_����  = MDEnum.valueOf(Enumerate0.class, java.lang.String.valueOf("5"));
    public static final Enumerate0 Enumerate0_����  = MDEnum.valueOf(Enumerate0.class, java.lang.String.valueOf("6"));
    public static final Enumerate0 Enumerate0_����  = MDEnum.valueOf(Enumerate0.class, java.lang.String.valueOf("7"));
    public static final Enumerate0 Enumerate0_��Ϣ  = MDEnum.valueOf(Enumerate0.class, java.lang.String.valueOf("8"));
    public static final Enumerate0 Enumerate0_ֵ��  = MDEnum.valueOf(Enumerate0.class, java.lang.String.valueOf("9"));

}
