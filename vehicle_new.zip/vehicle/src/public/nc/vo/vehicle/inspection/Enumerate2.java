package nc.vo.vehicle.inspection;

import nc.md.model.IEnumValue;
import nc.md.model.impl.MDEnum;


public class Enumerate2 extends MDEnum{
	public Enumerate2(IEnumValue enumValue){
		super(enumValue);
	}

    public static final Enumerate2 Enumerate2_��˳����  = MDEnum.valueOf(Enumerate2.class, java.lang.String.valueOf("1"));
    public static final Enumerate2 Enumerate2_����  = MDEnum.valueOf(Enumerate2.class, java.lang.String.valueOf("2"));
    public static final Enumerate2 Enumerate2_����  = MDEnum.valueOf(Enumerate2.class, java.lang.String.valueOf("3"));
    public static final Enumerate2 Enumerate2_��ţ��  = MDEnum.valueOf(Enumerate2.class, java.lang.String.valueOf("4"));
    public static final Enumerate2 Enumerate2_������  = MDEnum.valueOf(Enumerate2.class, java.lang.String.valueOf("5"));

}
