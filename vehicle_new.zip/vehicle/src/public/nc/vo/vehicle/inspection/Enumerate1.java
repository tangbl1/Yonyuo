package nc.vo.vehicle.inspection;

import nc.md.model.IEnumValue;
import nc.md.model.impl.MDEnum;


public class Enumerate1 extends MDEnum{
	public Enumerate1(IEnumValue enumValue){
		super(enumValue);
	}

    public static final Enumerate1 Enumerate1_ë����  = MDEnum.valueOf(Enumerate1.class, java.lang.String.valueOf("1"));
    public static final Enumerate1 Enumerate1_��ţ��  = MDEnum.valueOf(Enumerate1.class, java.lang.String.valueOf("2"));
    public static final Enumerate1 Enumerate1_������  = MDEnum.valueOf(Enumerate1.class, java.lang.String.valueOf("3"));
    public static final Enumerate1 Enumerate1_����  = MDEnum.valueOf(Enumerate1.class, java.lang.String.valueOf("4"));
    public static final Enumerate1 Enumerate1_�Ӷ�  = MDEnum.valueOf(Enumerate1.class, java.lang.String.valueOf("5"));

}
