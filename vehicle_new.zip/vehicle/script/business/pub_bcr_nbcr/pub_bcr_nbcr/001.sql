insert into PUB_BCR_NBCR ( CODE,CODELENTH,PK_NBCR,CODESCOPE,CODESTYLE,METAID,NAME,ORGTYPE,DR,TS ) values  ( 'vehiclevorder',40,'1001AA1LCP00000RGJET','global','both','93aadcd3-b1ff-4fe4-8f2c-9214ae3154fd','用车申请单','BUSINESSUNIT00000000',null,null ) 
/

