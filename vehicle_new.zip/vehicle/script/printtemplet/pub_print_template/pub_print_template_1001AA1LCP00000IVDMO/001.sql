insert into PUB_PRINT_TEMPLATE ( APPCODE,BDIRECTOR,BDISPAGENUM,BDISTOTALPAGENUM,BILLSPACE,BNORMALCOLOR,CTEMPLATEID,DEVORG,DR,EXTENDATTR,FFONTSTYLE,FPAGINATION,IBOTMARGIN,IBREAKPOSITION,IFONTSIZE,IGRIDCOLOR,ILEFTMARGIN,IPAGEHEIGHT,IPAGELOCATE,IPAGEWIDTH,IRIGHTMARGIN,ISCALE,ITOPMARGIN,ITYPE,LAYER,MDCLASS,MODEL_TYPE,MODELHEIGHT,MODELWIDTH,PK_CORP,PK_ORG,PREPARE1,PREPARE2,PTEMPLATEID,TS,VDEFAULTPRINTER,VFONTNAME,VLEFTNOTE,VMIDNOTE,VNODECODE,VRIGHTNOTE,VTEMPLATECODE,VTEMPLATENAME ) values  ( '40VE01','N','N','N',null,'N','1001AA1LCP00000IVDMO','~',0,'<nc.vo.pub.print.PrintTemplateExtVO>
  <isBindUp>false</isBindUp>
  <zdline__position>0.0</zdline__position>
  <pagehead__position>0.0</pagehead__position>
  <pagetail__position>0.0</pagetail__position>
  <pagenumber__position>0.0</pagenumber__position>
  <m__withFullPageNumber>false</m__withFullPageNumber>
  <baseLineWeight>0.65</baseLineWeight>
  <initPageNo>1</initPageNo>
</nc.vo.pub.print.PrintTemplateExtVO>
','0',0,20,0,9,-4144960,20,595,21,595,20,100,20,1,0,'93aadcd3-b1ff-4fe4-8f2c-9214ae3154fd',null,null,null,'@@@@','~','000000001000','false','~','2023-04-28 14:27:45',null,'SimSun','第','页 共','@@@@','页','40VE01_card','用车申请单卡片打印模板' ) 
/

