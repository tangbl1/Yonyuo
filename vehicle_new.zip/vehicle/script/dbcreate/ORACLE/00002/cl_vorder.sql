create index i_cl_vorder_b_1 on CL_VORDER_B (pk_vorder asc) 
/

